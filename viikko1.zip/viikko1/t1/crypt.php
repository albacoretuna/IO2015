<?php
// TODO: liitä funktiot.php ( yhteiset kansiossa, require_once() )
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Teht 1</title>
</head>

<body>
<?php
// TODO: uudelleenohjaa selain takaisin tähän tiedostoon siten että osoite alkaa https.... (ks. funktiot.php)


if( empty($_POST['teksti']) ):
?>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <input type="text" name="teksti">
        <input type="submit" value="lähetä">
    </form>
<?php
else:
	// TODO: hae lähetetty teksti $_POST[]:in avulla
	// TODO: tulosta teksti
	// TODO: tiivistä teksti MD5 algoritmilla ( hash() -funktio )
	// TODO: tulosta MD5 tiivistetty teksti
	// TODO: tiivistä teksti sha256 algoritmilla ( hash() -funktio )
	// TODO: tulosta SHA256 tiivistetty teksti
endif;
?>
</body>
</html>