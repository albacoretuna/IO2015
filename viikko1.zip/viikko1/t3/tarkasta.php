<?php
// TODO: liitä funktiot.php ( yhteiset kansiossa, require_once() )
// TODO: pistä https päälle (ks. funktiot.php)
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Tarkasta</title>
</head>

<body>
<?php

if( empty($_POST['email']) && empty($_POST['pwd']) ):
?>
	<form action="tarkasta.php" method="post">
        <input type="text" name="email" placeholder="sähköposti">
        <br>
        <input type="password" name="pwd" placeholder="salasana">
        <br>
        <input type="submit" value="kirjaudu" name="submit">
    </form>
<?php
else :
	// TODO: hae lähetetty email ja pwd $_POST[]:in avulla
	
	$lauseke1 = XXX; // TODO: tee säännöllinen lauseke, joka tarkastaa onko email sähköpostiosoite
	
	if( preg_match($lauseke1, $email) ){
		$email = true;
	} else {
		$email = false;	
	}
	
	$lauseke2 = XXX; // TODO: tee säännöllinen lauseke, joka tarkastaa onko pwd:ssä vähintään 1 iso kirjain
	$lauseke3 = XXX; // TODO: tee säännöllinen lauseke, joka tarkastaa onko pwd:ssä vähintään 1 numero
	$lauseke4 = XXX; // TODO: tee säännöllinen lauseke, joka tarkastaa onko pwd vähintään 8 merkkiä pitkä
	
	if( preg_match($lauseke2, $pwd) && preg_match($lauseke3, $pwd) && preg_match($lauseke4, $pwd) ){
		$passwd = true;
	} else {
		$passwd = false;	
	}
	
	// TODO: tee seuraavanlainen if-lause
	// jos $email ja $passwd ovat tosia
	// uudelleenohjaa tiedostoon ok.php ( redirect(), tämä löytyy funktiot.php:stä )
	// muutoin näytä lomake uudestaan (eli uudelleenohjaa takaisin tähän tiedostoon)
	
endif;

?>
</body>
</html>