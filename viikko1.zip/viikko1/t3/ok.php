<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>OK</title>
</head>

<body>
<p>Email ja salasana ovat vissiin OK.</p>
</body>
</html>